// JavaScript Array
var synths = [
    {id: 0, name: 'Korg Poly 800', price: 250.00},
    {id: 1, name: 'Nord Micro Modular', price: 400.00},
    {id: 2, name: 'Elektron Monomachine', price: 500.00},
    ];
    
